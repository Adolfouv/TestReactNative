import React, { useEffect, useState } from 'react';
import {ScrollView, Text, View, Button} from 'react-native';
import {Image} from 'react-native' ; 


export default App = () => {
  const [isLoading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  console.log(data);
      /* A partir del metodo fetch('') se realiza la consulta al servicio REST por medio del URL
    */
  useEffect(() => {
    fetch('https://0q27loouph.execute-api.us-east-1.amazonaws.com/')
      .then((response) => response.json())
      .then((json) => setData(json))
      .catch((error) => console.error(error))
      .finally(() => setLoading(false));
  }, []);
 
  
  return ( 
    <View style={{ flex: 1}}>
      {isLoading ? <Text style= {{textAlign:'center', fontSize: 25}}>Cargando...</Text> : 
      (
         <ScrollView style={{ flex: 1, flexDirection: 'column'}}>
           
             {/*A partir de un componente <Text> se llama a cada variable/atributo del archivo/objeto json: "name", "email", "phone", "nutritionist" */}

        <Text style={{ fontSize: 55, color: 'green', textAlign: 'center'}}
          >Nombre:</Text>
          <Text style={{flex:1, fontSize: 18, color: 'green', textAlign: 'center', paddingBottom: 15}}>{data.name}</Text>
        <Text style={{ fontSize: 55, color: 'green', textAlign: 'center', paddingBottom: 10}}
          >Email:</Text>  
          <Text style={{ fontSize: 18, color: 'green', textAlign: 'center', paddingBottom: 15}}>{data.email}</Text>
        <Text style={{ fontSize: 55, color: 'green', textAlign: 'center', paddingBottom: 10}}
          >Contacto:</Text>  
          <Text style={{ fontSize: 18, color: 'green', textAlign: 'center', paddingBottom: 15}}>{data.phone}</Text>
        <Text style={{ fontSize: 55, color: 'green', textAlign: 'center', paddingBottom: 10}}
          >Nutricionista:</Text> 
          <Text style={{ fontSize: 18, color: 'green', textAlign: 'center'}}>{data.nutritionist}</Text>
        <Text style={{ fontSize: 55, color: 'green', textAlign: 'center', paddingBottom: 10}}></Text>   
        <Text style={{ fontSize: 55, color: 'green', textAlign: 'center', paddingBottom: 1}}></Text>  
          <ScrollView data={data.ordenados}/> 
            <Image style={{ borderWidth: 5, left:70, width: 200, height: 100, resizeMode: 'center' }} source={{ uri:'http://placeimg.com/640/480' }} />
          {/*El boton de actualizar datos no funciona por lo que se queda en proceso de estudio. */}  
            <Button onPress={() => this.bug} title="Actualizar datos" />
           </ScrollView>
      )}
    </View>     
  );
};